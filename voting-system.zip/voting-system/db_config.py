# db_config.py

MYSQL_HOST = 'localhost'
MYSQL_USER = 'root'  # Change this if you're using a different MySQL username
MYSQL_PASSWORD = '27421'  # Leave blank if you don't have a password
MYSQL_DB = 'voting_db'  # This is the name of your database
